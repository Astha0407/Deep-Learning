# Deep-Learning

- Understand that different initialization methods and their impact on your model performance

- Implement zero initialization and and see it fails to "break symmetry",

- Recognize that random initialization "breaks symmetry" and yields more efficient models,

- Understand that you could use both random initialization and scaling to get even better training performance on your model.




- Understand that different regularization methods that could help your model.

- Implement dropout and see it work on data.

- Recognize that a model without regularization gives you a better accuracy on the training set but nor necessarily on the test set.

- Understand that you could use both dropout and regularization on your model.
